# Reflection:
This project can proceed smoothly. As it was the first time to use an outside source to edit a web page, I encountered some 

problems at the beginning, for example, I did not know how to insert images in index. md, so I spent some time trying to solve 

it, but it did not work, finally I consulted Ben, and the problem was solved quickly. Through this study, I also mastered 

how to use the outside source insert picture, as well as insert text. In addition, I know how to use 11TY to create a static 

website. However, there were some problems with this assignment. For example, I can skillfully use div class in regular web page

(index.html) editing, I couldn't use div properly. After using markdown to insert the image, I tried to edit images separately 

using divs in the index. html page, but it didn't work. Although the entire page is not affected by images, I still want to 

solve these problems in order to make my page looks different.

# Action 
What I'm going to do next is try to solve these problems. I'm going to try to solve some of the problems through the relevant 

web pages and videos, and it may take a while, but it's worth it.

